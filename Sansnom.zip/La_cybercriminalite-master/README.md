# DUT Info Projet S1
Projet de site web statique pour S1 de DUT Info.
